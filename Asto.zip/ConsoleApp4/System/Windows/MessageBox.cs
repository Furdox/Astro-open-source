﻿using System;

namespace ConsoleApp4.System.Windows
{
    internal class MessageBox
    {
        internal static object Show(string v1, string v2)
        {
            throw new NotImplementedException();
        }
    }
}