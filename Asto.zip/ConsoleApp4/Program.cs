﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Windows;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Blue; Console.WriteLine("Welcome to Astro");
            Thread.Sleep(2000); //2 second wait
            Console.ForegroundColor = ConsoleColor.Cyan; Console.WriteLine("Made by Duсky#0001 and k¶Z#0965");
            Thread.Sleep(2000); //2 second wait
            Console.WriteLine("Type username below for your account");
            string user = Console.ReadLine();
            Thread.Sleep(2000); //2 second wait
            Console.ForegroundColor = ConsoleColor.Blue; Console.WriteLine($"Welcome {user} to Astro");
            //if u skid this ur super fucking gay 
            Thread.Sleep(2000); //2 second wait
            Console.WriteLine("Type Background (Backgrounds are in the server)");
            string output = Console.ReadLine();
            Thread.Sleep(3000); //3 second wait
            Console.WriteLine($"Background set to {output}");
            Thread.Sleep(2000); //3 second wait
            Console.WriteLine("Launching Fortnite Please wait");
            Thread.Sleep(2000); //3 second wait
            {
                try
                {
                    Process.Start("com.epicgames.launcher://apps/Fortnite?action=launch&silent=true");
                }
                catch
                {
                  
                }
            }
            Console.WriteLine("Launched!");
            Thread.Sleep(6000); //3 second wait
            Console.ForegroundColor = ConsoleColor.Blue; Console.WriteLine("If you want to kill fortnite game Type kill under this if you dont keep this windows open AT ALL TIMES ");
            Console.ReadLine();
            Console.WriteLine("Killing fortnite please wait...");
            Thread.Sleep(5000); //3 second wait
            Process[] processesByName = Process.GetProcessesByName("Fortnitelauncher");
            for (int i = 0; i < processesByName.Length; i++)
            {
                processesByName[i].Kill();
            }
            processesByName = Process.GetProcessesByName("FortniteClient-Win64-Shipping_EAC");
            for (int i = 0; i < processesByName.Length; i++)
            {
                processesByName[i].Kill();
            }
            processesByName = Process.GetProcessesByName("FortniteClient-Win64-Shipping");
            for (int i = 0; i < processesByName.Length; i++)
            {
                processesByName[i].Kill();
            }
            processesByName = Process.GetProcessesByName("FortniteClient-Win64-Shipping_BE");
            for (int i = 0; i < processesByName.Length; i++)
            {
                processesByName[i].Kill();
            }
            object p = System.Windows.MessageBox.Show("Game Killed succesfully", "Astro 16.50");



            Console.ReadLine();
        }
    }
}
